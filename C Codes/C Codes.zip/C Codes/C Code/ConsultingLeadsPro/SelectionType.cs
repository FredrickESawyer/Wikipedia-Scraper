using System;
namespace ConsultingLeadsPro
{
	public enum SelectionType
	{
		Text,
		Control,
		None
	}
}
