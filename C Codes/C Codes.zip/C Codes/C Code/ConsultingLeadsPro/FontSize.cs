using System;
namespace ConsultingLeadsPro
{
	public enum FontSize
	{
		One,
		Two,
		Three,
		Four,
		Five,
		Six,
		Seven,
		NA
	}
}
