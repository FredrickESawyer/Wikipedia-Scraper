using System;
namespace ConsultingLeadsPro
{
	public enum ReadyState
	{
		Uninitialized,
		Loading,
		Loaded,
		Interactive,
		Complete
	}
}
