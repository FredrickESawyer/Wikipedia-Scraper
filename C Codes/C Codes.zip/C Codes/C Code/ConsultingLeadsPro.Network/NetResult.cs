using System;
namespace ConsultingLeadsPro.Network
{
	public enum NetResult
	{
		Success,
		ServerDown,
		Failed
	}
}
