using System;
namespace ConsultingLeadsPro.Callbacks
{
	public interface LogCallback
	{
		void Log(string text);
	}
}
